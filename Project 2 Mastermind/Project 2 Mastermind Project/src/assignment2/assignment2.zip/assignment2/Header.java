/*  * EE422C Project 2 (Mastermind) submission by
 * Replace <...> with your actual data. 
 * <Student Name>
 * <Student EID>
 * Slip days used: <0>
 * Fall 2016
 */
